@extends('layout.v_template')
@section('title', 'Data Semester')

@section('content')
<button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#add">
   <i class="fa fa-plus"></i> Tambah Data Semester
 </button> <br><br>
    
 @if (session('pesan'))
    <div class="alert alert-success alert-dismissible">
           <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{ session('pesan') }}
      </div>          
    @endif
     <div class="card shadow mb-4">
        <div class="card-header py-3">
          <h6 class="m-0 font-weight-bold text-primary">Data Semester</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
           <thead>
                <tr>
                    <th>No</th>
                    <th>Semester</th>
                    <th>Action</th>
                </tr>
           </thead> 
           <tbody>
                <?php $no=1; ?>
                @foreach ($semester as $data)
                    <tr>
                        <td>{{ $no++ }}</td>
                        <td>{{ $data->semester }}</td>
                        
                        <td>
                            <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#edit{{ $data->id }}"> 
                               Edit
                           </button> 
                            <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#delete{{ $data->id }}">
                               Delete
                           </button>
                       </td>
                
                    </tr>
                @endforeach
           </tbody>
      </table>
    </div>
</div>
</div>


<!--Modal Add-->
<div class="modal modal-danger fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Semester</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      <form action="/semester/insert" method="POST">
         @csrf

                <div class="form-group">
                    <label>Semester</label>
                    <input type="text" name="semester" class="form-control" value="{{ old('semester') }}">
                     
                </div>

                
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
        </form>
      </div>
    </div>
  </div>
</div>

<!--Modal Edit-->
@foreach($semester as $data)
<div class="modal modal-danger fade" id="edit{{ $data->id }}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Data Semester</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      <form action="/semester/update/{{ $data->id }}" method="POST">
         @csrf

                <div class="form-group">
                    <label>Semester</label>
                     <input type="text" name="semester" class="form-control" value="{{ $data->semester }}">
                     <div class="text-danger">    
                        @error('semester')
                                {{ $message }}
                        @enderror
                    </div>
                </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
        </form>
      </div>
    </div>
  </div>
</div>
@endforeach


<!-- Modal Delete-->
@foreach($semester as $data)
<div class="modal modal-danger fade" id="delete{{ $data->id }}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{ $data->semester }}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Apakah Anda Yakin Ingin Hapus Data Ini..???
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
        <a href="/semester/delete/{{ $data->id }}" class="btn btn-danger">Yes</a>
      </div>
    </div>
  </div>
</div>
@endforeach
@endsection