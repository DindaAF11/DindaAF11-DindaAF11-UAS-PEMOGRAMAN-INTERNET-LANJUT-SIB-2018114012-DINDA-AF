@extends('layout.v_template')
@section('title', 'Data Mahasiswa')

@section('content')
<button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#add">
   <i class="fa fa-plus"></i> Tambah Mahasiswa
 </button> <br><br>

 @if (session('pesan'))
    <div class="alert alert-success alert-dismissible">
           <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{ session('pesan') }}
      </div>          
    @endif
    
     <div class="card shadow mb-4">
        <div class="card-header py-3">
          <h6 class="m-0 font-weight-bold text-primary">Data Mahasiswa</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
           <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Mahasiswa</th>
                    <th>Alamat</th>
                    <th>No Telepon</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
           </thead> 
           <tbody>
                <?php $no=1; ?>
                @foreach ($mahasiswa as $data)
                    <tr>
                        <td>{{ $no++ }}</td>
                        <td>{{ $data->nama_mahasiswa }}</td>
                        <td>{{ $data->alamat }}</td>
                        <td>{{ $data->no_tlp }}</td>
                        <td>{{ $data->email }}</td>
                        <td>
                            
                             <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#edit{{ $data->id }}"> 
                                Edit
                            </button> 
                             <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#delete{{ $data->id }}">
                                Delete
                            </button>
                        </td>
                    </tr>
                @endforeach
           </tbody>
      </table>
    </div>
    </div>
    </div>


<!--Modal Add-->
<div class="modal modal-danger fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Mahasiswa</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      <form action="/mahasiswa/insert" method="POST">
         @csrf

                <div class="form-group">
                    <label>Nama Mahasiswa</label>
                     <input type="text" name="nama_mahasiswa" class="form-control" value="{{ old('nama_mahasiswa') }}">
                     
                </div>

                <div class="form-group">
                    <label>Alamat</label>
                    <input type="text" name="alamat" class="form-control" value="{{ old('alamat') }}">
                    
                </div>

                <div class="form-group">
                    <label>No Telpon</label>
                     <input type="text" name="no_tlp" class="form-control" value="{{ old('tlp') }}">
                     
                </div>

                <div class="form-group">
                    <label>Email</label>
                     <input type="text" name="email" class="form-control" value="{{ old('email') }}">
                    
                </div>
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
        </form>
      </div>
    </div>
  </div>
</div>



<!--Modal Edit-->
@foreach($mahasiswa as $data)
<div class="modal modal-danger fade" id="edit{{ $data->id }}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Data Mahasiswa</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      <form action="/mahasiswa/update/{{ $data->id }}" method="POST">
         @csrf

                <div class="form-group">
                    <label>Nama Mahasiswa</label>
                     <input type="text" name="nama_mahasiswa" class="form-control" value="{{ $data->nama_mahasiswa }}">
                     <div class="text-danger">    
                        @error('nama_mahasiswa')
                                {{ $message }}
                        @enderror
                    </div>
                </div>

                <div class="form-group">
                    <label>Alamat</label>
                    <input type="text" name="alamat" class="form-control" value="{{ $data->alamat }}">
                    <div class="text-danger">    
                        @error('alamat')
                                {{ $message }}
                        @enderror
                    </div>
                </div>

                <div class="form-group">
                    <label>No Telpon</label>
                     <input type="text" name="no_tlp" class="form-control" value="{{ $data->no_tlp }}">
                     <div class="text-danger">    
                        @error('no_tlp')
                                {{ $message }}
                        @enderror
                    </div>
                </div>

                <div class="form-group">
                    <label>Email</label>
                     <input type="text" name="email" class="form-control" value="{{ $data->email }}">
                     <div class="text-danger">    
                        @error('email')
                                {{ $message }}
                        @enderror
                    </div>
                </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
        </form>
      </div>
    </div>
  </div>
</div>
@endforeach



<!-- Modal Delete-->
@foreach($mahasiswa as $data)
<div class="modal modal-danger fade" id="delete{{ $data->id }}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{ $data->nama_mahasiswa }}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Apakah Anda Yakin Ingin Hapus Data Ini..???
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
        <a href="/mahasiswa/delete/{{ $data->id }}" class="btn btn-danger">Yes</a>
      </div>
    </div>
  </div>
</div>
@endforeach
@endsection