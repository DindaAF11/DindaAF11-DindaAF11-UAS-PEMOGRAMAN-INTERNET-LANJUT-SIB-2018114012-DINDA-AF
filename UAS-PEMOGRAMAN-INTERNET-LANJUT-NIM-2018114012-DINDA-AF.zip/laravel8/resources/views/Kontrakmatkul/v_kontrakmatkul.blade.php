@extends('layout.v_template')
@section('title', 'Data Kontrak Matakuliah')

@section('content')
<button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#add">
   <i class="fa fa-plus"></i> Tambah Kontrak Kuliah
 </button> <br><br>

 @if (session('pesan'))
    <div class="alert alert-success alert-dismissible">
           <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{ session('pesan') }}
      </div>          
    @endif
    
     <div class="card shadow mb-4">
        <div class="card-header py-3">
          <h6 class="m-0 font-weight-bold text-primary">Data Kontrak Kuliah</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
           <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Mahasiswa</th>
                    <th>Semester</th>
                    <th>Action</th>
                </tr>
           </thead> 
           <tbody>
                <?php $no=1; ?>
                @foreach ($kontrakmatkul as $data)
                    <tr>
                        <td>{{ $no++ }}</td>
                        <td>{{ $data->mahasiswa_id }}</td>
                        <td>{{ $data->semester_id }}</td>
                        <td>
                            <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#edit{{ $data->id }}"> 
                               Edit
                           </button> 
                            <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#delete{{ $data->id }}">
                               Delete
                           </button>
                       </td>
                
                    </tr>
                @endforeach
           </tbody>
      </table>
    </div>
</div>
</div>


<!--Modal Add-->
<div class="modal modal-danger fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Kontrak matakuliah</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      <form action="/matakuliah/insert" method="POST">
         @csrf

                <div class="form-group">
                    <label>Nama Mahasiswa</label>
                     <input type="text" name="mahasiswa_id" class="form-control" value="{{ old('nama_matakuliah') }}">
                     
                </div>

                <div class="form-group">
                    <label>Semester</label>
                    <input type="text" name="semester_id" class="form-control" value="{{ old('sks') }}">
                    
                </div>
              
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
        </form>
      </div>
    </div>
  </div>
</div>


<!--Modal Edit-->
@foreach($kontrakmatkul as $data)
<div class="modal modal-danger fade" id="edit{{ $data->id }}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Data Mata Kuliah</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      <form action="/matakuliah/update/{{ $data->id }}" method="POST">
         @csrf

                <div class="form-group">
                    <label>Nama Mata Kuliah</label>
                     <input type="text" name="nama_matakuliah" class="form-control" value="{{ $data->nama_matakuliah }}">
                     <div class="text-danger">    
                        @error('nama_matakuliah')
                                {{ $message }}
                        @enderror
                    </div>
                </div>

                <div class="form-group">
                    <label>Sks</label>
                    <input type="text" name="sks" class="form-control" value="{{ $data->sks }}">
                    <div class="text-danger">    
                        @error('sks')
                                {{ $message }}
                        @enderror
                    </div>
                </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
        </form>
      </div>
    </div>
  </div>
</div>
@endforeach


@endsection