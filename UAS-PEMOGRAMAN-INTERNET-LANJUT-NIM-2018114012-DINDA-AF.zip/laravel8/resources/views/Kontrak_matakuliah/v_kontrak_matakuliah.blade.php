@extends('layout.v_template')
@section('title', 'Data Kontrak Matakuliah')

@section('content')
<button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#add">
   <i class="fa fa-plus"></i> Tambah Kontrak Matakuliah
 </button> <br><br>
    
     <div class="card shadow mb-4">
        <div class="card-header py-3">
          <h6 class="m-0 font-weight-bold text-primary">Data Kontrak Matakuliah</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
           <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Mahasiswa</th>
                    <th>Semester</th>
                    
                </tr>
           </thead> 
           <tbody>
                <?php $no=1; ?>
                @foreach ($kontrak_matakuliah as $data)
                    <tr>
                        <td>{{ $no++ }}</td>
                        <td>{{ $data->nama_mahasiswa }}</td>
                        <td>{{ $data->semester }}</td>
                        
                    </tr>
                @endforeach
           </tbody>
      </table>
    </div>
</div>
</div>

<!--Modal Add-->
<div class="modal modal-danger fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Kontrak Mata Kuliah</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      <form action="/jadwal/insert" method="POST">
         @csrf

         <div class="form-group">
                    <label>Nama Mahasiswa</label>
                     <select name="mahasiswa_id" class="form-control">
                        <option value="">--Pilih--</option>
                        @foreach($kontrak_matakuliah as $data)
                            <option value="{{ $data->id }}">{{ $data->nama_mahasiswa }}</option>
                        @endforeach
                     </select>
                </div>

                <div class="form-group">
                    <label>Semester</label>
                     <select name="semester_id" class="form-control">
                        <option value="">--Pilih--</option>
                        @foreach($kontrak_matakuliah as $data)
                            <option value="{{ $data->id }}">{{ $data->semester }}</option>
                        @endforeach
                     </select>
                </div>

        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
        </form>
      </div>
    </div>
  </div>
</div>

@endsection