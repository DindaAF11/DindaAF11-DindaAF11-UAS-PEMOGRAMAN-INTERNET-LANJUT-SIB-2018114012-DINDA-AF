@extends('layout.v_template')
@section('title', 'Data Jadwal')

@section('content')
<button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#add">
   <i class="fa fa-plus"></i> Tambah Jadwal
 </button> <br><br>
    
 @if (session('pesan'))
    <div class="alert alert-success alert-dismissible">
           <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{ session('pesan') }}
      </div>          
    @endif
    
     <div class="card shadow mb-4">
        <div class="card-header py-3">
          <h6 class="m-0 font-weight-bold text-primary">Data Jadwal</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
           <thead>
                <tr>
                    <th>No</th>
                    <th>Jadwal</th>
                    <th>Mata Kuliah</th>
                    
                </tr>
           </thead> 
           <tbody>
                <?php $no=1; ?>
                @foreach ($jadwal as $data)
                    <tr>
                        <td>{{ $no++ }}</td>
                        <td>{{ $data->jadwal }}</td>
                        <td>{{ $data->nama_matakuliah }}</td>
                        
                    </tr>
                @endforeach
           </tbody>
      </table>
    </div>
</div>
</div>

<!--Modal Add-->
<div class="modal modal-danger fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Jadwal</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      <form action="/jadwal/insert" method="POST">
         @csrf

                <div class="form-group">
                    <label>Jadwal</label>
                     <input type="text" name="jadwal" class="form-control" value="{{ old('jadwal') }}">
                     
                </div>

                <div class="form-group">
                    <label>Mata Kuliah</label>
                     <select name="matakuliah_id" class="form-control">
                        <option value="">--Pilih--</option>
                        @foreach($jadwal as $data)
                            <option value="{{ $data->id }}">{{ $data->nama_matakuliah }}</option>
                        @endforeach
                     </select>
                </div>

        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
        </form>
      </div>
    </div>
  </div>
</div>
@endsection