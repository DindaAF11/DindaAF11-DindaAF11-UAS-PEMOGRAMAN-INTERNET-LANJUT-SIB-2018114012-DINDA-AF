@extends('layout.v_template')
@section('title', 'Data Mahasiswa')

@section('content')
<button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#add">
   <i class="fa fa-plus"></i> Tambah Absen
 </button> <br><br>
    
     <div class="card shadow mb-4">
        <div class="card-header py-3">
          <h6 class="m-0 font-weight-bold text-primary">Data Absen</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
           <thead>
                <tr>
                    <th>No</th>
                    <th>Waktu Absen</th>
                    <th>Nama Mahasiswa</th>
                    <th>Mata Kuliah</th>
                    <th>Keterangan</th>
                    
                </tr>
           </thead> 
           <tbody>
                <?php $no=1; ?>
                @foreach ($absen as $data)
                    <tr>
                        <td>{{ $no++ }}</td>
                        <td>{{ $data->waktu_absen }}</td>
                        <td>{{ $data->nama_mahasiswa }}</td>
                        <td>{{ $data->nama_matakuliah	 }}</td>
                        <td>{{ $data->keterangan }}</td>
                    </tr>
                @endforeach
           </tbody>
      </table>
    </div>
</div>
</div>

<!--Modal Add-->
<div class="modal modal-danger fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Absen</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      <form action="/jadwal/insert" method="POST">
         @csrf

                <div class="form-group">
                    <label>Jadwal</label>
                     <input type="text" name="jadwal" class="form-control" value="{{ old('jadwal') }}">
                     
                </div>


                <div class="form-group">
                    <label>Nama Mahasiswa</label>
                     <select name="mahasiswa_id" class="form-control">
                        <option value="">--Pilih--</option>
                        @foreach($absen as $data)
                            <option value="{{ $data->id }}">{{ $data->nama_mahasiswa }}</option>
                        @endforeach
                     </select>
                </div>

                <div class="form-group">
                    <label>Mata Kuliah</label>
                     <select name="semester_id" class="form-control">
                        <option value="">--Pilih--</option>
                        @foreach($absen as $data)
                            <option value="{{ $data->id }}">{{ $data->nama_matakuliah }}</option>
                        @endforeach
                     </select>
                </div>


                <div class="form-group">
                    <label>Keterangan</label>
                     <input type="text" name="keterangan" class="form-control" value="{{ old('keterangan') }}">
                     
                </div>
              

        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
        </form>
      </div>
    </div>
  </div>
</div>



@endsection