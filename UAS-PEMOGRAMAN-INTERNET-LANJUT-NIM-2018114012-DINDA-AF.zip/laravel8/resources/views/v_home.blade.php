@extends('layout.v_template')
@section('title', 'Home')
@section('content')
    <h4>{{ $selamat }}</h4>
   
@endsection