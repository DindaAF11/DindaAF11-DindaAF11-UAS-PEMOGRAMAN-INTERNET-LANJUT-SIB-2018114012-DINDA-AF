@extends('layout.v_template')
@section('title', 'Data Mata Kuliah')

@section('content')
<button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#add">
   <i class="fa fa-plus"></i> Tambah Mata Kuliah
 </button> <br><br>

 @if (session('pesan'))
    <div class="alert alert-success alert-dismissible">
           <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            {{ session('pesan') }}
      </div>          
    @endif
    
     <div class="card shadow mb-4">
        <div class="card-header py-3">
          <h6 class="m-0 font-weight-bold text-primary">Data Mata Kuliah</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
           <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Matakuliah</th>
                    <th>Sks</th>
                    <th>Action</th>
                </tr>
           </thead> 
           <tbody>
                <?php $no=1; ?>
                @foreach ($matakuliah as $data)
                    <tr>
                        <td>{{ $no++ }}</td>
                        <td>{{ $data->nama_matakuliah }}</td>
                        <td>{{ $data->sks }}</td>
                        <td>
                            <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#edit{{ $data->id }}"> 
                               Edit
                           </button> 
                            <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#delete{{ $data->id }}">
                               Delete
                           </button>
                       </td>
                
                    </tr>
                @endforeach
           </tbody>
      </table>
    </div>
</div>
</div>


<!--Modal Add-->
<div class="modal modal-danger fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Mata Kuliah</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      <form action="/matakuliah/insert" method="POST">
         @csrf

                <div class="form-group">
                    <label>Nama Mata Kuliah</label>
                     <input type="text" name="nama_matakuliah" class="form-control" value="{{ old('nama_matakuliah') }}">
                     
                </div>

                <div class="form-group">
                    <label>Sks</label>
                    <input type="text" name="sks" class="form-control" value="{{ old('sks') }}">
                    
                </div>
              
        </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
        </form>
      </div>
    </div>
  </div>
</div>


<!--Modal Edit-->
@foreach($matakuliah as $data)
<div class="modal modal-danger fade" id="edit{{ $data->id }}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Data Mata Kuliah</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      <form action="/matakuliah/update/{{ $data->id }}" method="POST">
         @csrf

                <div class="form-group">
                    <label>Nama Mata Kuliah</label>
                     <input type="text" name="nama_matakuliah" class="form-control" value="{{ $data->nama_matakuliah }}">
                     <div class="text-danger">    
                        @error('nama_matakuliah')
                                {{ $message }}
                        @enderror
                    </div>
                </div>

                <div class="form-group">
                    <label>Sks</label>
                    <input type="text" name="sks" class="form-control" value="{{ $data->sks }}">
                    <div class="text-danger">    
                        @error('sks')
                                {{ $message }}
                        @enderror
                    </div>
                </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
        </form>
      </div>
    </div>
  </div>
</div>
@endforeach


<!-- Modal Delete-->
@foreach($matakuliah as $data)
<div class="modal modal-danger fade" id="delete{{ $data->id }}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">{{ $data->nama_matakuliah }}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Apakah Anda Yakin Ingin Hapus Data Ini..???
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
        <a href="/matakuliah/delete/{{ $data->id }}" class="btn btn-danger">Yes</a>
      </div>
    </div>
  </div>
</div>
@endforeach
@endsection