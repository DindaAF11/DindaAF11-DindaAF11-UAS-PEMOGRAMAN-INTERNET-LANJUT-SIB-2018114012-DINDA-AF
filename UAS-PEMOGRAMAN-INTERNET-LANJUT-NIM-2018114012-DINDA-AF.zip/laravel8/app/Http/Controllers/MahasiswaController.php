<?php

namespace App\Http\Controllers;

use App\Models\Mahasiswa;
use Illuminate\Http\Request;
use\App\Models\MahasiswaModel;

class MahasiswaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->Mahasiswa = new Mahasiswa();
    } 

    public function index()
    {
        $data = [
            'mahasiswa' => $this->Mahasiswa->allData()
        ];
        return view('Mahasiswa.v_mahasiswa', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function add()
    {
        return view('Mahasiswa.v_mahasiswa');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function insert()
    {
        $data = [
            'nama_mahasiswa' => Request()->nama_mahasiswa,
            'alamat' => Request()->alamat,
            'no_tlp' => Request()->no_tlp,
            'email' => Request()->email,
        ];
    
        $this->Mahasiswa->addData($data);
        return redirect()->route('mahasiswa')->with('pesan', 'Data Berhasil Di Tambahkan !!!');
    
    
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Mahasiswa  $mahasiswa
     * @return \Illuminate\Http\Response
     */
    public function show(Mahasiswa $mahasiswa)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Mahasiswa  $mahasiswa
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = [
            'mahasiswa' => $this->Mahasiswa->getAllData($id),
        ]; 

        return view('Mahasiswa.v_mahasiswa', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Mahasiswa  $mahasiswa
     * @return \Illuminate\Http\Response
     */
    public function update($id)
    {
        $data = [
            'nama_mahasiswa' => Request()->nama_mahasiswa,
            'alamat' => Request()->alamat,
            'no_tlp' => Request()->no_tlp,
            'email' => Request()->email,
        ];
    
            $this->Mahasiswa->editData($id, $data);
            return redirect ()->route('mahasiswa')->with('pesan', 'Data Berhasil Di Update !!!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Mahasiswa  $mahasiswa
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        // hapus atau delete 
        $mahasiswa = $this->Mahasiswa->getAllData($id);

        $this->Mahasiswa->deleteData($id);
        return redirect()->route('mahasiswa')->with('pesan', 'Data Berhasil Di Hapus !!!');

    }
}
