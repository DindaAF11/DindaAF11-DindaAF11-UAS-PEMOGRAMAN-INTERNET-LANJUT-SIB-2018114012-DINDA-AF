<?php

namespace App\Http\Controllers;

use App\Models\Jadwal;
use\App\Models\Matakuliah;
use Illuminate\Http\Request;

class JadwalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->Jadwal = new Jadwal();
    } 

    public function index()
    {
        $data = [
            'jadwal' => $this->Jadwal->allDatajadwal('nama_matakuliah'),
        ];

        return view('Jadwal.v_jadwal', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function add($id)
    {
       return view('Jadwal.v_jadwal');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function insert()
    {
        $data = [
            'jadwal' => Request()->jadwal,
            'matakuliah_id' => Request()->matakuliah_id,
        ];
    
        $this->Jadwal->addData($data);
        return redirect()->route('jadwal')->with('pesan', 'Data Berhasil Di Tambahkan !!!');
    
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Jadwal  $jadwal
     * @return \Illuminate\Http\Response
     */
    public function show(Jadwal $jadwal)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Jadwal  $jadwal
     * @return \Illuminate\Http\Response
     */
    public function edit(Jadwal $jadwal)
    {
        $data = [
            'jadwal' => $this->Jadwal->getAllData($id),
        ]; 
        return view('Jadwal.v_jadwal', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Jadwal  $jadwal
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Jadwal $jadwal)
    {
        $data = [
            'jadwal' => Request()->jadwal,
            'matakuliah_id' => Request()->matakuliah_id,
        ];

        $this->Jadwal->editData($id, $data);
        return redirect ()->route('jadwal')->with('pesan', 'Data Berhasil Di Update !!!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Jadwal  $jadwal
     * @return \Illuminate\Http\Response
     */
    public function destroy(Jadwal $jadwal)
    {
        $jadwal = $this->Jadwal->getAllData($id);

        $this->Jadwal->deleteData($id);
        return redirect()->route('jadwal')->with('pesan', 'Data Berhasil Di Hapus !!!');
    }
}
