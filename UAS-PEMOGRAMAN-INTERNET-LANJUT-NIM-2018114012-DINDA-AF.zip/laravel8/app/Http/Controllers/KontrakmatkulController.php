<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Kontrakmatkul;
use App\Models\Mahasiswa;
use App\Models\Semester;

class KontrakmatkulController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->Kontrakmatkul = new Kontrakmatkul();
    } 

    public function index()
    {
        $data = [
            'kontrak_matakuliah' => $this->Kontrakmatkul ->allData()
        ];
        return view('Kontrak_matakuliah.v_kontrak_matakuliah', $data);
    }

    public function add()
    {
        
        return view('Kontrak_matakuliah.v_kontrak_matakuliah');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function insert()
    {

        $data = [
            'mahasiswa_id' => Request()->nama_mahasiswa,
            'semester_id' => Request()->semester,
        ];
    
        $this->Kontrakmatkul->addData($data, $mhs);
        return redirect()->route('kontrak_matakuliah')->with('pesan', 'Data Berhasil Di Tambahkan !!!');
    
    
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Kontrakmatkul  $kontrakmatkul
     * @return \Illuminate\Http\Response
     */
    public function show(Kontrakmatkul $kontrakmatkul)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Kontrakmatkul  $kontrakmatkul
     * @return \Illuminate\Http\Response
     */
    public function edit(Kontrakmatkul $kontrakmatkul)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Kontrakmatkul  $kontrakmatkul
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Kontrakmatkul $kontrakmatkul)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Kontrakmatkul  $kontrakmatkul
     * @return \Illuminate\Http\Response
     */
    public function destroy(Kontrakmatkul $kontrakmatkul)
    {
        //
    }
}
