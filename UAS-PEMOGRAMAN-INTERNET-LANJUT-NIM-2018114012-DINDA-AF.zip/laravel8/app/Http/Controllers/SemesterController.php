<?php

namespace App\Http\Controllers;

use App\Models\Semester;
use Illuminate\Http\Request;

class SemesterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->Semester = new Semester();
    } 

    public function index()
    {
        $data = [
            'semester' => $this->Semester->allDatasemester()
        ];
        return view('Semester.v_semester', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function add()
    {
        return view('Semester.v_semester');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function insert()
    {
        $data = [
            'semester' => Request()->semester,
        ];
    
        $this->Semester->addData($data);
        return redirect()->route('semester')->with('pesan', 'Data Berhasil Di Tambahkan !!!');
    
    
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Semester  $semester
     * @return \Illuminate\Http\Response
     */
    public function show(Semester $semester)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Semester  $semester
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = [
            'semester' => $this->Semester->getAllData($id),
        ]; 
        return view('Semester.v_semester', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Semester  $semester
     * @return \Illuminate\Http\Response
     */
    public function update($id)
    {
        $data = [
            'semester' => Request()->semester,
        ];

        $this->Semester->editData($id, $data);
        return redirect ()->route('semester')->with('pesan', 'Data Berhasil Di Update !!!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Semester  $semester
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        // hapus atau delete 
        $semester = $this->Semester->getAllData($id);

        $this->Semester->deleteData($id);
        return redirect()->route('semester')->with('pesan', 'Data Berhasil Di Hapus !!!');

    }
}
