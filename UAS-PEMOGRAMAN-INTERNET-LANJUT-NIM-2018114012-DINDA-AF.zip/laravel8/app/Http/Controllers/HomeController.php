<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $data = [
            'selamat' => 'Selamat Datang Di Aplikasi Absensi Mahasiswa',
           
        ];
        return view('v_home', $data);
    }
}
