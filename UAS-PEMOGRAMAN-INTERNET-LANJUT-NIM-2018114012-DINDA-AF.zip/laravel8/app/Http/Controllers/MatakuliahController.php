<?php

namespace App\Http\Controllers;

use App\Models\Matakuliah;
use Illuminate\Http\Request;

class MatakuliahController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   
    public function __construct()
    {
        $this->Matakuliah = new Matakuliah();
    } 

    public function index()
    {
        $data = [
            'matakuliah' => $this->Matakuliah->allData()
        ];
        return view('Matakuliah.v_matakuliah', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function add()
    {
        return view('Matakuliah.v_matakuliah');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function insert()
    {
        $data = [
            'nama_matakuliah' => Request()->nama_matakuliah,
            'sks' => Request()->sks,
        ];
    
        $this->Matakuliah->addData($data);
        return redirect()->route('matakuliah')->with('pesan', 'Data Berhasil Di Tambahkan !!!');
    
    
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Matakuliah  $matakuliah
     * @return \Illuminate\Http\Response
     */
    public function show(Matakuliah $matakuliah)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Matakuliah  $matakuliah
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = [
            'mahasiswa' => $this->Mahasiswa->getAllData($id),
        ]; 
        return view('Matakuliah.v_matakuliah', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Matakuliah  $matakuliah
     * @return \Illuminate\Http\Response
     */
    public function update($id)
    {
        $data = [
            'nama_matakuliah' => Request()->nama_matakuliah,
            'sks' => Request()->sks,
        ];

        $this->Matakuliah->editData($id, $data);
        return redirect ()->route('matakuliah')->with('pesan', 'Data Berhasil Di Update !!!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Matakuliah  $matakuliah
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        // hapus atau delete
        $matakuliah = $this->Matakuliah->getAllData($id);

        $this->Matakuliah->deleteData($id);
        return redirect()->route('matakuliah')->with('pesan', 'Data Berhasil Di Hapus !!!');

    }
}
