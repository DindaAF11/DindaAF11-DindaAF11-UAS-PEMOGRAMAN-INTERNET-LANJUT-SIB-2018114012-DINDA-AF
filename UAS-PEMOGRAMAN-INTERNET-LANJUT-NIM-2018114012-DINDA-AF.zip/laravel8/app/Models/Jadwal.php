<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Jadwal extends Model
{
    use HasFactory;

    protected $primaryKey = 'id';
    protected $fillable = [
        'jadwal',
        'matakuliah_id'
    ];

    public function allDatajadwal()
    {
        return DB::table('jadwals')
        ->leftJoin('matakuliahs', 'matakuliahs.id', '=', 'jadwals.id')
        ->get();
    }

    public function addData($data)
    {
        DB::table('jadwals')->insert($data);
    }


}
