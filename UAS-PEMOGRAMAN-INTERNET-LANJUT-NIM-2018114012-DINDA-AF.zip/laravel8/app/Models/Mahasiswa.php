<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Mahasiswa extends Model
{
    use HasFactory;

    protected $primaryKey = 'id';
    protected $fillable = [
        'nama_mahasiswa',
        'alamat',
        'no_tlp',
        'email'
    ];

    public function allData()
    {
        return DB::table('mahasiswas')->get();
    }

    public function getAllData($id)
    {
        return DB::table('mahasiswas')->where('id', $id)->first();
    }

    public function addData($data)
    {
        DB::table('mahasiswas')->insert($data);
    }

    public function editData($id, $data)
    {
        DB::table('mahasiswas')
        ->where('id', $id)
        ->update($data);
    }

    public function deleteData($id)
    {
        DB::table('mahasiswas')
        ->where('id', $id)
        ->delete();
    }

}
