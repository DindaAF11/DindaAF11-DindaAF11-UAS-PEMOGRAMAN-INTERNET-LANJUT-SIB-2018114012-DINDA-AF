<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Absen extends Model
{
    use HasFactory;

    protected $fillable = [
        'waktu_absen',
        'mahasiswa_id',
        'matakuliah_id'
    ];

    public function allData()
    {
       return DB::table('absens')
       ->leftJoin('mahasiswas', 'mahasiswas.id', '=', 'absens.id')
       ->leftJoin('matakuliahs', 'matakuliahs.id', '=', 'absens.id')
       ->get();
    }
}
