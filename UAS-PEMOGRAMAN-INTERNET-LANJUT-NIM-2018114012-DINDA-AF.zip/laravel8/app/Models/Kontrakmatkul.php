<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;


class Kontrakmatkul extends Model
{
    use HasFactory;

    protected $fillable = [
        'mahasiswa_id',
        'semester_id'
    ];

    public function allData()
    {
       return DB::table('kontrakmatkuls')
       ->leftJoin('mahasiswas', 'mahasiswas.id', '=', 'kontrakmatkuls.id')
       ->leftJoin('semesters', 'semesters.id', '=', 'kontrakmatkuls.id')
       ->get();
    }

    public function addData($data)
    {
        DB::table('kontrakmatkuls')->insert($data);
    }
}
