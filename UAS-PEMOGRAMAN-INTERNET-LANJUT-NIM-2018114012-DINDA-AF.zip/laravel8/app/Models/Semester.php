<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Semester extends Model
{
    use HasFactory;

    protected $primaryKey = 'id';
    protected $fillable = [
        'semester'
    ];

    public function allDatasemester()
    {
        return DB::table('semesters')->get();
    }

    public function getAllData($id)
    {
        return DB::table('semesters')->where('id', $id)->first();
    }

    public function addData($data)
    {
        DB::table('semesters')->insert($data);
    }

    public function editData($id, $data)
    {
        DB::table('semesters')
        ->where('id', $id)
        ->update($data);
    }

    public function deleteData($id)
    {
        DB::table('semesters')
        ->where('id', $id)
        ->delete();
    }
}
