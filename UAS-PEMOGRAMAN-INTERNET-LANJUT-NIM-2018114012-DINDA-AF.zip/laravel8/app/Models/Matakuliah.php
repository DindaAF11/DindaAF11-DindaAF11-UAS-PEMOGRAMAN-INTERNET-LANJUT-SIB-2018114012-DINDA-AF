<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Matakuliah extends Model
{
    use HasFactory;

    protected $primaryKey = 'id';
    protected $fillable = [
        'nama_matakuliah',
        'sks'
    ];

    public function allData()
    {
        return DB::table('matakuliahs')->get();
    }

    public function getAllData($id)
    {
        return DB::table('matakuliahs')->where('id', $id)->first();
    }

    public function addData($data)
    {
        DB::table('matakuliahs')->insert($data);
    }

    public function editData($id, $data)
    {
        DB::table('matakuliahs')
        ->where('id', $id)
        ->update($data);
    }

    public function deleteData($id)
    {
        DB::table('matakuliahs')
        ->where('id', $id)
        ->delete();
    }
}
