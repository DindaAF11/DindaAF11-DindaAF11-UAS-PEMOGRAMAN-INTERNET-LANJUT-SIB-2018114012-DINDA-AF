<?php

use Illuminate\Support\Facades\Route;
use\App\Http\Controllers\HomeController;
use\App\Http\Controllers\MahasiswaController;
use\App\Http\Controllers\AbsenController;
use\App\Http\Controllers\MatakuliahController;
use\App\Http\Controllers\SemesterController;
use\App\Http\Controllers\JadwalController;
use\App\Http\Controllers\KontrakmatkulController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', [HomeController::class, 'index']);

Route::get('/mahasiswa', [MahasiswaController::class, 'index'])->name('mahasiswa');
Route::get('/mahasiswa/add', [MahasiswaController::class, 'add']);
Route::post('/mahasiswa/insert', [MahasiswaController::class, 'insert']);
Route::get('/mahasiswa/edit/{id}', [MahasiswaController::class, 'edit']);
Route::post('/mahasiswa/update/{id}', [MahasiswaController::class, 'update']);
Route::get('/mahasiswa/delete/{id}', [MahasiswaController::class, 'delete']);

// Absen
Route::get('/absen', [AbsenController::class, 'index']);
Route::get('/absen/add', [AbsenController::class, 'add']);

// Matakuliah
Route::get('/matakuliah', [MatakuliahController::class, 'index'])->name('matakuliah');
Route::get('/matakuliah/add', [MatakuliahController::class, 'add']);
Route::post('/matakuliah/insert', [MatakuliahController::class, 'insert']);
Route::get('/matakuliah/edit/{id}', [MatakuliahController::class, 'edit']);
Route::post('/matakuliah/update/{id}', [MatakuliahController::class, 'update']);
Route::get('/matakuliah/delete/{id}', [MatakuliahController::class, 'delete']);

// Semester
Route::get('/semester', [SemesterController::class, 'index'])->name('semester');
Route::get('/semester/add', [SemesterController::class, 'add']);
Route::post('/semester/insert', [SemesterController::class, 'insert']);
Route::get('/semester/edit/{id}', [SemesterController::class, 'edit']);
Route::post('/semester/update/{id}', [SemesterController::class, 'update']);
Route::get('/semester/delete/{id}', [SemesterController::class, 'delete']);

// Jadwal
Route::get('/jadwal', [JadwalController::class, 'index'])->name('jadwal');
Route::get('/jadwal/add', [JadwalController::class, 'add']);
Route::post('/jadwal/insert', [JadwalController::class, 'insert']);

// Kontrak Mata Kuliah
Route::get('/kontrak_matakuliah', [KontrakmatkulController::class, 'index'])->name('kontrak_matakuliah');
Route::get('/kontrak_matakuliah/add', [KontrakmatkulController::class, 'add']);
Route::post('/kontrak_matakuliah/insert', [KontrakmatkulController::class, 'insert']);