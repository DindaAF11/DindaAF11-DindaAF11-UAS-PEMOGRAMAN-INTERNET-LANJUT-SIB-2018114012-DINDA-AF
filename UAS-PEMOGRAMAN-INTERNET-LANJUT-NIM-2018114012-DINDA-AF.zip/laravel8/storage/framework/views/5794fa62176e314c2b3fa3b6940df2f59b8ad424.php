
<?php $__env->startSection('title', 'Data Distributor'); ?>

<?php $__env->startSection('content'); ?>
     <a href="/distributor/add" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i> Tambah Buku</a> <br><br>
    <?php if(session('pesan')): ?>
    <div class="alert alert-success alert-dismissible">
           <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo e(session('pesan')); ?>

      </div>          
    <?php endif; ?>
     <div class="card shadow mb-4">
        <div class="card-header py-3">
          <h6 class="m-0 font-weight-bold text-primary">Data Distributor</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
           <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Distributor</th>
                    <th>Alamat</th>
                    <th>Telpon</th>
                    <th>Action</th>
                </tr>
           </thead> 
           <tbody>
                <?php $no=1; ?>
                <?php $__currentLoopData = $distributor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($data->nama_distributor); ?></td>
                        <td><?php echo e($data->alamat); ?></td>
                        <td><?php echo e($data->telepon); ?></td>
                        <td>
                             <a href="/distributor/edit/<?php echo e($data->id_distributor); ?>" class="btn btn-sm btn-warning"> Edit</a>
                             <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#delete<?php echo e($data->id_distributor); ?>">
                                Delete
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tbody>
      </table>
    </div>
    </div>
    </div>




<!-- Modal -->

<?php $__currentLoopData = $distributor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal modal-danger fade" id="delete<?php echo e($data->id_distributor); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><?php echo e($data->nama_distributor); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Apakah Anda Yakin Ingin Hapus Data Ini..???
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
        <a href="/distributor/delete/<?php echo e($data->id_distributor); ?>" class="btn btn-primary">Yes</a>
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toko-buku\resources\views/v_distributor.blade.php ENDPATH**/ ?>