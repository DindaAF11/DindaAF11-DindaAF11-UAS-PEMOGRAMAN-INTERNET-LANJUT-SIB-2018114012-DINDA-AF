
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
    <div class="sidebar-brand-icon rotate-n-15">
        <i class="#"></i>
    </div>
    <div class="sidebar-brand-text mx-3">ABSENSI MAHASISWA</div>
</a>

<!-- Divider -->
<hr class="sidebar-divider my-0">

<!-- Nav Item - Dashboard -->
<li class="nav-item">
    <a class="nav-link" href="/">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Dashboard</span></a>
</li>


<!-- Nav Item - Charts -->
<li class="nav-item">
    <a class="nav-link" href="/mahasiswa">
        <i class="fas fa-users"></i>
        <span>Mahasiswa</span></a>
</li>

<!-- Nav Item - Tables -->
<li class="nav-item">
    <a class="nav-link" href="/absen">
        <i class="fas fa-fw fa-table"></i>
        <span>Absen</span></a>
</li>

<li class="nav-item">
    <a class="nav-link" href="matakuliah">
        <i class="fas fa-fw fa-table"></i>
        <span>Matakuliah</span></a>
</li>

<li class="nav-item">
    <a class="nav-link" href="/kontrak_matakuliah">
        <i class="fas fa-fw fa-book"></i>
        <span>Kontrak Matakuliah</span></a>
</li>

<li class="nav-item">
    <a class="nav-link" href="/jadwal">
        <i class="fas fa-fw fa-folder"></i>
        <span>Jadwal</span></a>
</li>


<li class="nav-item">
    <a class="nav-link" href="/semester">
        <i class="fas fa-fw fa-file"></i>
        <span>Semester</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>

</ul><?php /**PATH C:\laravel8\resources\views/layout/v_sidebar.blade.php ENDPATH**/ ?>