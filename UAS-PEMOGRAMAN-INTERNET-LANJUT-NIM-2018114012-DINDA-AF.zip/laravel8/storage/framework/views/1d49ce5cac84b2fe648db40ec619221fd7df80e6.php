
<?php $__env->startSection('title', 'Data Penjualan'); ?>

<?php $__env->startSection('content'); ?>
      <a href="" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i>Tambah Buku</a> <br><br>
   

       <div class="card shadow mb-4">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold <text-primary">Data Penjualan</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                     <table class="table table-bordered" id="dataTable" width="100%" cellaspacing="0">
                 <thead>
                         <tr>
                           <th>NO</th>
                           <th>Nama Kasir</th>
                           <th>Jumlah</th>
                           <th>Total</th>
                           <th>Tanggal</th>
                           <th>Aksi</th>
                        </tr>
                    </thead>
                     <tbody>
                           <?php $no=1; ?>
                           <?php $__currentLoopData = $penjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                         <td> <?php echo e($no++); ?> </td>
                                         <td> <?php echo e($data->id_kasir); ?> </td>
                                         <td> <?php echo e($data->jumlah); ?> </td>
                                         <td> <?php echo e($data->total); ?> </td>
                                         <td> <?php echo e($data->tanggal); ?> </td>
                                      
                                         <td>
                                              <a href="" class="btn btn-sm btn-warning"> Edit</a>
                                              <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#delete">
                                                delete
                                                </button>
                                          </td>
                                     </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                  </div>
                </div>
                </div>
<?php $__env->stopSection(); ?>

                                              
                                              
                                              

                     
                
<?php echo $__env->make('layout.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toko-buku\resources\views/v_penjualan.blade.php ENDPATH**/ ?>