
<?php $__env->startSection('title', 'Edit Data Buku'); ?>
<?php $__env->startSection('content'); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit Data Buku</h6>
        </div>
            <div class="card-body">
         <form action="/buku/update/<?php echo e($buku->id_buku); ?>" method="POST" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>

            <div class="row">
                <div class="col">
                    <label>Judul</label>
                     <input type="text" name="judul" class="form-control" value="<?php echo e($buku->judul); ?>">
                     <div class="text-danger">    
                        <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col">
                    <label>NO ISBN</label>
                    <input type="text" name="noisbn" class="form-control" value="<?php echo e($buku->noisbn); ?>">
                    <div class="text-danger">    
                        <?php $__errorArgs = ['noisbn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <label>Penulis</label>
                     <input type="text" name="penulis" class="form-control" value="<?php echo e($buku->penulis); ?>">
                     <div class="text-danger">    
                        <?php $__errorArgs = ['penulis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col">
                    <label>Penerbit</label>
                    <input type="text" name="penerbit" class="form-control" value="<?php echo e($buku->penerbit); ?>">
                    <div class="text-danger">    
                        <?php $__errorArgs = ['penerbit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <label>Tahun</label>
                     <input type="date" name="tahun" class="form-control" value="<?php echo e($buku->tahun); ?>">
                     <div class="text-danger">    
                        <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col">
                    <label>Stok</label>
                    <input type="text" name="stok" class="form-control" value="<?php echo e($buku->stok); ?>">
                    <div class="text-danger">    
                        <?php $__errorArgs = ['stok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <label>Harga Pokok</label>
                     <input type="text" name="harga_pokok" class="form-control" value="<?php echo e($buku->harga_pokok); ?>">
                     <div class="text-danger">    
                        <?php $__errorArgs = ['harga_pokok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col">
                    <label>Harga Jual</label>
                    <input type="text" name="harga_jual" class="form-control" value="<?php echo e($buku->harga_jual); ?>">
                    <div class="text-danger">    
                        <?php $__errorArgs = ['harga_jual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>  

            <div class="row">
                <div class="col">
                    <label>PPN</label>
                     <input type="text" name="ppn" class="form-control" value="<?php echo e($buku->ppn); ?>">
                     <div class="text-danger">    
                        <?php $__errorArgs = ['ppn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col">
                    <label>Diskon</label>
                    <input type="text" name="diskon" class="form-control" value="<?php echo e($buku->diskon); ?>">
                    <div class="text-danger">    
                        <?php $__errorArgs = ['diskon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="col-sm-12">
                <div class="col-sm-4">
                    <img src="<?php echo e(url('foto_buku/'.$buku->foto_buku)); ?>"  width="150px mb-4">
                </div> 
               
                     <div class="row">
                        <div class="form-group">
                            <label>Ganti Foto Buku</label>
                            <input type="file" name="foto_buku" class="form-control">
                    <div class="text-danger">    
                        <?php $__errorArgs = ['foto_buku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                </div>
                 </div>
               </div>


            <div class="form-group">
                    <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
        
                    
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.v_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\toko-buku\resources\views/v_editbuku.blade.php ENDPATH**/ ?>